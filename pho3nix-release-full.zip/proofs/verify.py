#!/usr/bin/env python3
import os, json, hashlib, argparse, sys

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MANIFEST = os.path.join(BASE, "proofs", "manifest.json")
ROOTS = os.path.join(BASE, "proofs", "merkle_roots.json")

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def merkle_root(hex_list):
    nodes = [bytes.fromhex(h) for h in hex_list]
    if not nodes:
        return None
    while len(nodes) > 1:
        nxt = []
        for i in range(0, len(nodes), 2):
            left = nodes[i]
            right = nodes[i] if i+1 == len(nodes) else nodes[i+1]
            nxt.append(hashlib.sha256(left + right).digest())
        nodes = nxt
    return nodes[0].hex()

def rebuild():
    manifest = []
    for root, _, files in os.walk(BASE):
        for fn in files:
            rel = os.path.relpath(os.path.join(root, fn), BASE)
            if rel in ("proofs/manifest.json", "proofs/merkle_roots.json"):
                continue
            digest = sha256_file(os.path.join(BASE, rel))
            manifest.append({"path": rel, "sha256": digest})
    manifest = sorted(manifest, key=lambda x: x["path"])
    with open(MANIFEST, "w") as f:
        json.dump(manifest, f, indent=2)

    pub_files = ["README.md", "charter/morality_charter.md"]
    bundle_public = [m for m in manifest if m["path"] in pub_files]
    bundle_docs = [m for m in manifest if m["path"].startswith("docs/")]

    roots = {
        "public_bundle": {
            "files": [m["path"] for m in bundle_public],
            "merkle_root": merkle_root([m["sha256"] for m in bundle_public])
        },
        "docs_bundle": {
            "files": [m["path"] for m in bundle_docs],
            "merkle_root": merkle_root([m["sha256"] for m in bundle_docs])
        }
    }
    with open(ROOTS, "w") as f:
        json.dump(roots, f, indent=2)
    print("[REBUILD] manifest.json and merkle_roots.json updated.")

def verify():
    ok = True
    with open(MANIFEST, "r") as f:
        manifest = json.load(f)
    with open(ROOTS, "r") as f:
        roots = json.load(f)

    print("== File Integrity ==")
    for entry in manifest:
        p = os.path.join(BASE, entry["path"])
        if not os.path.exists(p):
            print(f"[MISS] {entry['path']} (file missing)")
            ok = False
            continue
        digest = sha256_file(p)
        if digest == entry["sha256"]:
            print(f"[PASS] {entry['path']}")
        else:
            print(f"[FAIL] {entry['path']} (expected {entry['sha256']}, got {digest})")
            ok = False

    print("\n== Merkle Roots ==")
    for name, bundle in roots.items():
        files = bundle["files"]
        digests = []
        for f in files:
            match = next((m for m in manifest if m["path"] == f), None)
            if not match:
                print(f"[FAIL] {name}: missing manifest entry for {f}")
                ok = False
                digests.append("")
            else:
                digests.append(match["sha256"])
        calc = merkle_root(digests)
        if calc == bundle["merkle_root"]:
            print(f"[PASS] {name}: {calc}")
        else:
            print(f"[FAIL] {name}: expected {bundle['merkle_root']}, got {calc}")
            ok = False

    print("\n== Summary ==")
    print("ALL PASS" if ok else "FAILURES DETECTED")
    return 0 if ok else 2

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rebuild", action="store_true")
    args = ap.parse_args()
    if args.rebuild:
        rebuild()
        sys.exit(0)
    else:
        if not os.path.exists(MANIFEST):
            rebuild()
        sys.exit(verify())
