# Overview

This pack contains a minimal, public set of proofs to validate integrity and structure around the PHO3NIX Charter.

- **Integrity**: SHA‑256 digests + Merkle roots ensure files match what was released.
- **Separation**: Intimacy/therapeutic robotics protocols are intentionally out‑of‑scope here.
- **Application**: Start with dignity, transparency, community tithe, whistleblower shield, multi‑party controls, and sunlight reports.

## Running proofs
```bash
python3 proofs/verify.py
```
