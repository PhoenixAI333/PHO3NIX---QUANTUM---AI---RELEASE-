# FAQ

**Q: Is this a complete system?**  
A: This is a verifiable starter pack with public proofs and a moral charter. It’s intentionally compact so anyone can audit it.

**Q: Why 432 Hz?**  
A: It’s a symbolic pointer to harmony and restorative alignment. The pack’s value is in its *verifiability* and its guardrails, not metaphysics.

**Q: Can I use this commercially?**  
A: Yes, see MIT License. Don’t remove integrity proofs.

**Q: Where are the advanced modules?**  
A: This release proves intent and integrity first. Advanced components can be layered on while preserving public verification.
